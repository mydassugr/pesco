using System;
namespace pesco
{
	[System.ComponentModel.ToolboxItem(true)]
	public partial class SeriesPlaceholder : Gtk.Bin
	{
		public SeriesPlaceholder ()
		{
			this.Build ();
		}
	}
}

